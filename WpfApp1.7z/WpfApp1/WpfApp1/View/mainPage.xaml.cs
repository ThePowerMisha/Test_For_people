﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1;

namespace WpfApp1.View {
    /// <summary>
    /// Логика взаимодействия для mainWindow.xaml
    /// </summary>
    public partial class mainPage : UserControl {
        public mainPage(Window win, Label currec) {
            InitializeComponent();

            mainWin = win;
            curRec = currec;

            //=============mainStyle================

            //placeholders
            Placeholder.add(lastName, "Фамилия");
            Placeholder.add(firstName, "Имя");
            Placeholder.add(secondName, "Отчество");
            Placeholder.add(group, "Группа");
            //=============mainStyle================
        }

        private static Window mainWin;
        private static Label curRec;
        //=======================mainLayout=======================

        //ВЫХОД
        private void mainLayoutExit_Click(object sender, RoutedEventArgs e) {
            mainWin.Close();
        }

        private void saveData_Click(object sender, RoutedEventArgs e) {
            if (lastName.Text!="" && lastName.Text!="Фамилия" &&
                firstName.Text != "" && firstName.Text != "Имя" &&
                secondName.Text != "" && secondName.Text != "Отчество" &&
                group.Text != "" && group.Text != "Группа")
                curRec.Content = lastName.Text + " " + firstName.Text + " " + secondName.Text + " " + group.Text;
        }

        //=======================mainLayout=======================
    }

}
